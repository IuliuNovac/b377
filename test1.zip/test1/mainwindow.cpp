#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <stdlib.h>
#include <stdio.h>
#include <QMessageBox>
#include <QSerialPort>
#include <QDebug>
#include <QSerialPortInfo>
#include <QIODevice>


QSerialPort *serial;

MainWindow::MainWindow(QWidget *parent) :
QMainWindow(parent),
ui(new Ui::MainWindow)
{
ui->setupUi(this);
//setup for serialpoart usage
serial = new QSerialPort(this);
serial->setPortName("COM3");
serial->open(QIODevice::ReadOnly);
serial->setBaudRate(QSerialPort::Baud9600);
serial->setDataBits(QSerialPort::Data8);
serial->setParity(QSerialPort::NoParity);
serial->setStopBits(QSerialPort::OneStop);
serial->setFlowControl(QSerialPort::NoFlowControl);
connect(serial,SIGNAL(readyRead()),this,SLOT(serialReceived()));
MainWindow::MakePlot();
timer = new QTimer(this);
connect(timer, SIGNAL(timeout()),this,SLOT(MakePlot()));
}

MainWindow::~MainWindow()
{
delete ui;
}

void MainWindow::serialReceived()
{

QByteArray serialData = serial->readAll();
QString input = QString::fromStdString(serialData.toStdString());
ui->lcdNumber->display(input);

}
void MainWindow::MakePlot()
{
    //timer causes a crash
    //timer->start(1000);
    QByteArray serialData = serial->readAll();
    QString input = QString::fromStdString(serialData.toStdString());

    double n = input.toDouble();

    // generate some data:
    QVector<double> x(101), y(101); // initialize with entries 0..100
    for (int i=0; i<101; ++i)
    {
      x[i] = n;
      y[i] = x[i]*x[i]; // let's plot a quadratic function
    }
    // create graph and assign data to it:
    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setData(x, y);
    // give the axes some labels:
    ui->customPlot->xAxis->setLabel("x");
    ui->customPlot->yAxis->setLabel("y");
    // set axes ranges, so we see all data:
    ui->customPlot->xAxis->setRange(0, 100);
    ui->customPlot->yAxis->setRange(0, 31);
    ui->customPlot->replot();
}
