#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QSerialPort>
#include <QDebug>
#include <QSerialPortInfo>
#include <QIODevice>

QSerialPort *serial;

MainWindow::MainWindow(QWidget *parent) :
QMainWindow(parent),
ui(new Ui::MainWindow)
{
ui->setupUi(this);
serial = new QSerialPort(this);
serial->setPortName("COM3");
serial->open(QIODevice::ReadOnly);
serial->setBaudRate(QSerialPort::Baud9600);
serial->setDataBits(QSerialPort::Data8);
serial->setParity(QSerialPort::NoParity);
serial->setStopBits(QSerialPort::OneStop);
serial->setFlowControl(QSerialPort::NoFlowControl);
connect(serial,SIGNAL(readyRead()),this,SLOT(serialReceived()));
    }

MainWindow::~MainWindow()
{
delete ui;
}

void MainWindow::serialReceived()
{

QByteArray serialData = serial->readAll();
QString input = QString::fromStdString(serialData.toStdString());
ui->lcdNumber->display(input);

}
